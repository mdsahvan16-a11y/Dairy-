package com.bharatdairy.app
import io.flutter.embedding.android.FlutterActivity
class MainActivity : FlutterActivity()
