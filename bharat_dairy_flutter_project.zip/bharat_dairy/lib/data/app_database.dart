import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final root = await getDatabasesPath();
    _db = await openDatabase(p.join(root, 'bharat_dairy.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE entries (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          kind TEXT NOT NULL, farmer TEXT NOT NULL, phone TEXT,
          animal TEXT NOT NULL, shift TEXT, quantity REAL NOT NULL,
          fat REAL NOT NULL DEFAULT 0, snf REAL NOT NULL DEFAULT 0,
          rate REAL NOT NULL, amount REAL NOT NULL, deductions REAL NOT NULL DEFAULT 0,
          date TEXT NOT NULL, created_at TEXT NOT NULL
        )''');
        await db.execute('''CREATE TABLE settings (
          key TEXT PRIMARY KEY, value TEXT NOT NULL
        )''');
        await db.insert('settings', {'key':'fat_factor','value':'0'});
        await db.insert('settings', {'key':'snf_factor','value':'0'});
        await db.insert('settings', {'key':'fixed_rate_cow','value':'0'});
        await db.insert('settings', {'key':'fixed_rate_buffalo','value':'0'});
      });
    return _db!;
  }

  Future<int> addEntry(Map<String, Object?> row) async => (await database).insert('entries', row);
  Future<List<Map<String, Object?>>> entries({String? month}) async {
    final db = await database;
    if (month == null) return db.query('entries', orderBy: 'date DESC, id DESC');
    return db.query('entries', where: 'substr(date,1,7)=?', whereArgs: [month], orderBy: 'date DESC, id DESC');
  }
  Future<Map<String, Object?>?> getSetting(String key) async {
    final rows = await (await database).query('settings', where:'key=?', whereArgs:[key], limit:1);
    return rows.isEmpty ? null : rows.first;
  }
  Future<void> setSetting(String key, String value) async => (await database).insert('settings', {'key':key,'value':value}, conflictAlgorithm: ConflictAlgorithm.replace);
  Future<int> deleteEntry(int id) async => (await database).delete('entries', where:'id=?', whereArgs:[id]);
}
