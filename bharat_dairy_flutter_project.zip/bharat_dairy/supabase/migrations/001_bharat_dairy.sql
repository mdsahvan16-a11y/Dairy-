-- Optional cloud schema. The current app build stores records locally on-device.
create extension if not exists pgcrypto;
create table if not exists public.dairy_entries (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  local_id text not null,
  kind text not null check (kind in ('collection','sale')),
  farmer text not null,
  phone text,
  animal text not null,
  shift text,
  quantity numeric(12,3) not null check (quantity > 0),
  fat numeric(5,2) not null default 0,
  snf numeric(5,2) not null default 0,
  rate numeric(12,2) not null,
  amount numeric(12,2) not null,
  deductions numeric(12,2) not null default 0,
  entry_date date not null,
  created_at timestamptz not null default now(),
  unique(owner_id, local_id)
);
alter table public.dairy_entries enable row level security;
create policy "Owners manage their own dairy entries" on public.dairy_entries
  for all using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
